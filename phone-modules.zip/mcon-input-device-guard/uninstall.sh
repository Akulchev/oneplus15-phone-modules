#!/system/bin/sh

STATE_DIR="/data/adb/mcon_input_device_guard"
PIDFILE="$STATE_DIR/daemon.pid"

if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
fi
rm -rf "$STATE_DIR"
