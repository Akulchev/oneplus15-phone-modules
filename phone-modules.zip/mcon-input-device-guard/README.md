# MCON Input Device Guard

A minimal KernelSU/Magisk module for the single paired controller
**OhSnap MCON I** at `configure your paired controller address`.

Every two seconds while Bluetooth is enabled, it restores only that controller's
Bluetooth HID Host connection policy to `100` — Android's **Input device**
toggle. It does not connect or disconnect devices, modify BLE scanning, unpair
anything, or change Bluetooth adapter state.
