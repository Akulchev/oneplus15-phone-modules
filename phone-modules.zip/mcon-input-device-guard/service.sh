#!/system/bin/sh

MODDIR="${0%/*}"
STATE_DIR="/data/adb/mcon_input_device_guard"
PIDFILE="$STATE_DIR/daemon.pid"
DEX="$MODDIR/bin/mcon-input-device-guard.dex"
CLASS="com.codex.mconfastconnect.MconReconnectMain"
# The controller's stable public address. Do not use the temporary LE address
# Android may show during a connection attempt.
ADDRESS="$(cat "$STATE_DIR/controller-address" 2>/dev/null)"
case "$ADDRESS" in
    ??:??:??:??:??:??) ;;
    *) exit 0 ;;
esac
DAEMON_ARG="--mcon-input-device-guard-daemon"

mkdir -p "$STATE_DIR"

pid_is_guard() {
    pid="$1"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null || return 1
    [ -r "/proc/$pid/cmdline" ] || return 1
    tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null \
        | grep -F "$MODDIR/service.sh" 2>/dev/null \
        | grep -F -- "$DAEMON_ARG" >/dev/null 2>&1
}

cleanup() {
    rm -f "$PIDFILE" 2>/dev/null
}

daemon() {
    until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
        sleep 2
    done
    trap cleanup EXIT
    trap 'exit 0' TERM INT

    while [ ! -f "$MODDIR/disable" ]; do
        if [ "$(settings get global bluetooth_on 2>/dev/null)" = "1" ] && [ -f "$DEX" ]; then
            # Policy-only mode never calls connect(), disconnect(), removeBond(),
            # or changes the Bluetooth adapter. It only writes HID_HOST=100 for
            # the exact bonded MCON address.
            CLASSPATH="$DEX" app_process /system/bin "$CLASS" \
                --policy-only "--address=$ADDRESS" >/dev/null 2>&1
        fi
        sleep 2
    done
}

if [ "$1" = "$DAEMON_ARG" ]; then
    daemon
    exit 0
fi

if [ -f "$PIDFILE" ] && pid_is_guard "$(cat "$PIDFILE" 2>/dev/null)"; then
    exit 0
fi

rm -f "$PIDFILE" 2>/dev/null
setsid sh "$MODDIR/service.sh" "$DAEMON_ARG" </dev/null >/dev/null 2>&1 &
echo "$!" > "$PIDFILE"
