#!/system/bin/sh

MODDIR="${0%/*}"
STATE_DIR="/data/adb/mcon_input_device_guard"
PIDFILE="$STATE_DIR/daemon.pid"

pid_is_guard() {
    pid="$1"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null || return 1
    [ -r "/proc/$pid/cmdline" ] || return 1
    tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null \
        | grep -F "$MODDIR/service.sh" 2>/dev/null \
        | grep -F -- '--mcon-input-device-guard-daemon' >/dev/null 2>&1
}

if [ -f "$MODDIR/disable" ]; then
    rm -f "$MODDIR/disable"
    sh "$MODDIR/service.sh"
    echo "MCON Input Device Guard enabled."
else
    touch "$MODDIR/disable"
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    pid_is_guard "$pid" && kill "$pid" 2>/dev/null
    echo "MCON Input Device Guard disabled."
fi
