package com.codex.mconfastconnect;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ReconnectReceiver extends BroadcastReceiver {
    private static final String TAG = "MconFastConnect";
    private static final String ACTION_CONNECT = "com.codex.mconfastconnect.CONNECT";
    private static final int PROFILE_HID_HOST = 4;
    private static final long TIMEOUT_MS = 8_000L;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION_CONNECT.equals(intent.getAction())) {
            return;
        }

        PendingResult pendingResult = goAsync();
        AtomicBoolean finished = new AtomicBoolean(false);
        Handler handler = new Handler(Looper.getMainLooper());

        Runnable finish = () -> {
            if (finished.compareAndSet(false, true)) {
                pendingResult.finish();
            }
        };
        handler.postDelayed(() -> {
            Log.w(TAG, "HID reconnect request timed out");
            finish.run();
        }, TIMEOUT_MS);

        try {
            BluetoothManager manager = context.getSystemService(BluetoothManager.class);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            if (adapter == null || !adapter.isEnabled()) {
                Log.w(TAG, "Bluetooth adapter is unavailable");
                finish.run();
                return;
            }

            List<BluetoothDevice> targets = findBondedMconDevices(adapter);
            if (targets.isEmpty()) {
                Log.w(TAG, "No bonded MCON device found");
                finish.run();
                return;
            }

            BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(int profile, BluetoothProfile proxy) {
                    boolean requested = false;
                    try {
                        Method connect = proxy.getClass().getMethod("connect", BluetoothDevice.class);
                        connect.setAccessible(true);
                        for (BluetoothDevice device : targets) {
                            Object result = connect.invoke(proxy, device);
                            requested |= result instanceof Boolean && (Boolean) result;
                        }
                        Log.i(TAG, "Privileged HID reconnect requested=" + requested);
                    } catch (ReflectiveOperationException | RuntimeException error) {
                        Log.e(TAG, "Privileged HID reconnect failed: "
                                + error.getClass().getSimpleName(), error);
                    } finally {
                        adapter.closeProfileProxy(profile, proxy);
                        finish.run();
                    }
                }

                @Override
                public void onServiceDisconnected(int profile) {
                    finish.run();
                }
            };

            if (!adapter.getProfileProxy(context, listener, PROFILE_HID_HOST)) {
                Log.w(TAG, "HID Host profile proxy request was rejected");
                finish.run();
            }
        } catch (RuntimeException error) {
            Log.e(TAG, "Reconnect setup failed: " + error.getClass().getSimpleName(), error);
            finish.run();
        }
    }

    private static List<BluetoothDevice> findBondedMconDevices(BluetoothAdapter adapter) {
        List<BluetoothDevice> result = new ArrayList<>();
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null) {
            return result;
        }

        for (BluetoothDevice device : bonded) {
            String name = device.getName();
            if (name != null && name.toLowerCase().contains("mcon")) {
                result.add(device);
            }
        }
        return result;
    }
}
