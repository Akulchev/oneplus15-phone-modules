package com.codex.mconfastconnect;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MconReconnectMain {
    private static final int PROFILE_HID_HOST = 4;
    private static final long TIMEOUT_MS = 8_000L;

    private MconReconnectMain() {}

    public static void main(String[] args) {
        try {
            boolean policyOnly = args != null && args.length > 0
                    && "--policy-only".equals(args[0]);
            String targetAddress = null;
            if (args != null) {
                for (String arg : args) {
                    if (arg.startsWith("--address=")) {
                        targetAddress = arg.substring("--address=".length());
                    }
                }
            }
            prepareMainLooper();
            Context context = createSystemContext();
            initializeBluetoothFramework();
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) {
                finish("MCON_RECONNECT_RESULT=adapter_null");
                return;
            }
            if (!adapter.isEnabled()) {
                finish("MCON_RECONNECT_RESULT=adapter_disabled");
                return;
            }

            List<BluetoothDevice> targets = findBondedMconDevices(adapter, targetAddress);
            if (targets.isEmpty()) {
                finish("MCON_RECONNECT_RESULT=no_bonded_mcon");
                return;
            }

            AtomicBoolean finished = new AtomicBoolean(false);
            Handler handler = new Handler(Looper.getMainLooper());
            Runnable timeout = () -> finishOnce(finished, "MCON_RECONNECT_RESULT=timeout");
            handler.postDelayed(timeout, TIMEOUT_MS);

            BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(int profile, BluetoothProfile proxy) {
                    boolean requested = false;
                    boolean inputEnabled = false;
                    try {
                        Method setConnectionPolicy = proxy.getClass().getMethod(
                                "setConnectionPolicy", BluetoothDevice.class, int.class);
                        setConnectionPolicy.setAccessible(true);
                        Method connect = proxy.getClass().getMethod("connect", BluetoothDevice.class);
                        connect.setAccessible(true);
                        for (BluetoothDevice target : targets) {
                            Object policyResult = setConnectionPolicy.invoke(proxy, target, 100);
                            inputEnabled |= policyResult instanceof Boolean && (Boolean) policyResult;
                            if (!policyOnly) {
                                Object result = connect.invoke(proxy, target);
                                requested |= result instanceof Boolean && (Boolean) result;
                            }
                        }
                        adapter.closeProfileProxy(profile, proxy);
                        finishOnce(finished, policyOnly
                                ? "MCON_POLICY_GUARD_RESULT=enabled_" + inputEnabled
                                : "MCON_RECONNECT_RESULT=input_enabled_"
                                        + inputEnabled + "_requested_" + requested);
                    } catch (ReflectiveOperationException | RuntimeException error) {
                        finishOnce(finished, "MCON_RECONNECT_RESULT=error_"
                                + error.getClass().getSimpleName());
                    }
                }

                @Override
                public void onServiceDisconnected(int profile) {
                    finishOnce(finished, "MCON_RECONNECT_RESULT=profile_disconnected");
                }
            };

            if (!adapter.getProfileProxy(context, listener, PROFILE_HID_HOST)) {
                finishOnce(finished, "MCON_RECONNECT_RESULT=proxy_rejected");
                return;
            }
            Looper.loop();
        } catch (Throwable error) {
            finish("MCON_RECONNECT_RESULT=fatal_" + error.getClass().getSimpleName());
        }
    }

    private static void prepareMainLooper() {
        if (Looper.getMainLooper() == null) {
            Looper.prepareMainLooper();
        }
    }

    private static Context createSystemContext() throws ReflectiveOperationException {
        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Method systemMain = activityThreadClass.getDeclaredMethod("systemMain");
        systemMain.setAccessible(true);
        Object activityThread = systemMain.invoke(null);
        Method getSystemContext = activityThreadClass.getDeclaredMethod("getSystemContext");
        getSystemContext.setAccessible(true);
        return (Context) getSystemContext.invoke(activityThread);
    }

    private static void initializeBluetoothFramework() throws ReflectiveOperationException {
        Class<?> initializerClass = Class.forName("android.bluetooth.BluetoothFrameworkInitializer");
        Method getManager = initializerClass.getDeclaredMethod("getBluetoothServiceManager");
        getManager.setAccessible(true);
        if (getManager.invoke(null) != null) {
            return;
        }

        Class<?> managerClass = Class.forName("android.os.BluetoothServiceManager");
        Object manager = managerClass.getDeclaredConstructor().newInstance();
        Method setManager = initializerClass.getDeclaredMethod(
                "setBluetoothServiceManager", managerClass);
        setManager.setAccessible(true);
        setManager.invoke(null, manager);
    }

    private static List<BluetoothDevice> findBondedMconDevices(BluetoothAdapter adapter,
            String targetAddress) {
        List<BluetoothDevice> result = new ArrayList<>();
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null) {
            return result;
        }
        for (BluetoothDevice device : bonded) {
            if (targetAddress != null && targetAddress.equalsIgnoreCase(device.getAddress())) {
                result.add(device);
                continue;
            }
            if (targetAddress != null) {
                continue;
            }
            String name = device.getName();
            if (name != null && name.toLowerCase().contains("mcon")) {
                result.add(device);
            }
        }
        return result;
    }

    private static void finishOnce(AtomicBoolean finished, String message) {
        if (finished.compareAndSet(false, true)) {
            finish(message);
        }
    }

    private static void finish(String message) {
        System.out.println(message);
        System.out.flush();
        System.exit(0);
    }
}
