#!/system/bin/sh
# KernelSU service: preserve stock thermal protection and add an earlier,
# hysteresis-based gaming ceiling driven by battery temperature.

BATTERY_TEMP=/sys/class/power_supply/battery/temp
GPU_MAX=/sys/class/kgsl/kgsl-3d0/max_gpuclk
USB_INPUT=/sys/devices/platform/soc/soc:oplus,mms_wired/oplus_mms/wired/usb/input_current_limit
CPU0_MAX=/sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
CPU6_MAX=/sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq

HOT_AT=380       # 38.0 C; battery sensor reports tenths of a degree.
COOL_AT=370      # 37.0 C release threshold; prevents rapid toggling.
COOL_GPU=646000000
COOL_USB_INPUT=500000
COOL_CPU0=1497600
COOL_CPU6=2112000
STOCK_GPU=1200000000
STOCK_USB_INPUT=2000000
STOCK_CPU0=3628800
STOCK_CPU6=4608000
HOT=0

write_value() {
    [ -w "$1" ] && echo "$2" > "$1" 2>/dev/null
}

apply_cool_profile() {
    write_value "$GPU_MAX" "$COOL_GPU"
    write_value "$USB_INPUT" "$COOL_USB_INPUT"
}

restore_profile() {
    write_value "$GPU_MAX" "$STOCK_GPU"
    write_value "$USB_INPUT" "$STOCK_USB_INPUT"
}

while true; do
    TEMP=$(cat "$BATTERY_TEMP" 2>/dev/null)
    case "$TEMP" in
        ''|*[!0-9]*) sleep 5; continue ;;
    esac

    if [ "$HOT" -eq 0 ] && [ "$TEMP" -ge "$HOT_AT" ]; then
        HOT=1
    elif [ "$HOT" -eq 1 ] && [ "$TEMP" -le "$COOL_AT" ]; then
        restore_profile
        HOT=0
    fi

    # Oplus power management can rewrite these controls asynchronously.
    # Reassert the ceiling while hot, while leaving stock thermal logic free
    # to apply stricter limits whenever it needs to.
    [ "$HOT" -eq 1 ] && apply_cool_profile
    sleep 5
done
