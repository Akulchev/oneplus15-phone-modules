#!/system/bin/sh
# KernelSU/Magisk service: foreground-triggered INCY VPN control.

MODDIR=${0%/*}
LOG="$MODDIR/auto-incy-vpn.log"
PIDFILE="$MODDIR/auto-incy-vpn.pid"
DELAY=60
TARGETS='com.instagram.android org.telegram.messenger com.android.chrome com.anthropic.claude com.discord com.google.android.googlequicksearchbox com.whatsapp'
INCY='llc.itdev.incy'

exec 1>>"$LOG" 2>&1
echo "$(date '+%F %T') module service started"

# Do not create a second monitor when the service is restarted.
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  exit 0
fi
echo $$ > "$PIDFILE"
trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT

is_target() {
  for app in $TARGETS; do [ "$1" = "$app" ] && return 0; done
  return 1
}

foreground_package() {
  dumpsys activity activities 2>/dev/null \
    | sed -n 's/.*topResumedActivity=ActivityRecord{[^ ]* u[0-9]* \([^/ ]*\)\/.*/\1/p' \
    | head -n 1
}

vpn_is_active() {
  dumpsys connectivity 2>/dev/null | grep -q "VPN\[.*ownerUid.*"
}

connect() {
  am broadcast -a "$INCY.CONNECT" -p "$INCY" >/dev/null 2>&1
  echo "$(date '+%F %T') connect requested"
}

disconnect() {
  am broadcast -a "$INCY.DISCONNECT" -p "$INCY" >/dev/null 2>&1
  echo "$(date '+%F %T') disconnect requested"
}

idle_since=0
last_connect_attempt=0
while true; do
  current="$(foreground_package)"
  now="$(date +%s)"
  if is_target "$current"; then
    idle_since=0
    # INCY shows an error dialog when its current profile is invalid.  Back off
    # failed starts so a broken profile cannot produce a continuous prompt loop.
    if ! vpn_is_active && [ $((now - last_connect_attempt)) -ge 30 ]; then
      connect
      last_connect_attempt=$now
    fi
  else
    if [ "$idle_since" -eq 0 ]; then idle_since=$now; fi
    if [ $((now - idle_since)) -ge "$DELAY" ] && vpn_is_active; then
      disconnect
      idle_since=$now
    fi
  fi
  sleep 2
done
