#!/system/bin/sh

MODDIR="${0%/*}"
STATE_DIR="/data/adb/mcon_xbox_bridge"
PIDFILE="$STATE_DIR/bridge.pid"
SERVICE_PIDFILE="$STATE_DIR/service.pid"

stop_legacy_pidfile() {
    file="$1"
    [ -f "$file" ] || return
    pid="$(cat "$file" 2>/dev/null)"
    command="$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)"
    case "$command" in
        *"$MODDIR/service.sh"*|*"getevent -ql"*) kill "$pid" 2>/dev/null ;;
    esac
}

stop_legacy_pidfile "$STATE_DIR/daemon.pid"
stop_legacy_pidfile "$STATE_DIR/home_watcher.pid"

if [ -f "$SERVICE_PIDFILE" ]; then
    service_pid="$(cat "$SERVICE_PIDFILE" 2>/dev/null)"
    [ -n "$service_pid" ] && kill "$service_pid" 2>/dev/null
fi

if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
fi
pkill -TERM -f "$MODDIR/bin/mcon_bridge --device" 2>/dev/null
rm -f "$PIDFILE" "$SERVICE_PIDFILE"
