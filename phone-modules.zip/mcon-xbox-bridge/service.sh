#!/system/bin/sh
# MCON Xbox Bridge: expose only the MCON as a virtual Xbox controller.

MODDIR="${0%/*}"
BIN="$MODDIR/bin/mcon_bridge"
STATE_DIR="/data/adb/mcon_xbox_bridge"
PIDFILE="$STATE_DIR/bridge.pid"
SERVICE_PIDFILE="$STATE_DIR/service.pid"
LOG="$STATE_DIR/mcon_xbox_bridge.log"
CODM_GLOBAL_PACKAGE="com.activision.callofduty.shooter"
CODM_GARENA_PACKAGE="com.garena.game.codm"

mkdir -p "$STATE_DIR"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

pid_alive() {
    [ -n "$1" ] && kill -0 "$1" 2>/dev/null
}

if [ -f "$SERVICE_PIDFILE" ] && pid_alive "$(cat "$SERVICE_PIDFILE" 2>/dev/null)"; then
    exit 0
fi
rm -f "$SERVICE_PIDFILE"
echo "$$" > "$SERVICE_PIDFILE"

bridge_running() {
    [ -f "$PIDFILE" ] && pid_alive "$(cat "$PIDFILE" 2>/dev/null)"
}

stop_bridge() {
    if [ -f "$PIDFILE" ]; then
        pid="$(cat "$PIDFILE" 2>/dev/null)"
        pid_alive "$pid" && kill "$pid" 2>/dev/null
        rm -f "$PIDFILE"
    fi
    pkill -TERM -f "$BIN --device" 2>/dev/null
}

current_foreground_package() {
    dumpsys window 2>/dev/null \
        | sed -n 's|.*mCurrentFocus=.* u[0-9][0-9]* \([^/ ]*\)/.*|\1|p'
}

is_codm_foreground() {
    case "$1" in
        "$CODM_GLOBAL_PACKAGE"|"$CODM_GARENA_PACKAGE") return 0 ;;
    esac
    return 1
}

# Deliberately conservative: claim only the known MCON VID/PID.  Android names
# it "Bluetooth HID", so its input-device uevent is the reliable identifier.
is_mcon() {
    path="$1"
    name="$2"
    lower="$(echo "$name" | tr 'A-Z' 'a-z')"
    case "$lower" in
        *"ohsnap mcon"*|*"mcon"*) return 0 ;;
    esac

    event="${path##*/}"
    uevent="$(cat "/sys/class/input/$event/device/uevent" 2>/dev/null)"
    case "$uevent" in
        *"PRODUCT=5/45e/b13/"*|*"PRODUCT=5/045e/0b13/"*) return 0 ;;
    esac
    return 1
}

find_mcon() {
    "$BIN" --list 2>> "$LOG" | while IFS="$(printf '\t')" read -r path name; do
        if [ -n "$path" ] && is_mcon "$path" "$name"; then
            echo "$path"
            break
        fi
    done
}

wait_for_boot() {
    until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
        sleep 2
    done
}

wait_for_boot
chmod 755 "$BIN" 2>/dev/null

# The physical MCON is only claimed while Call of Duty: Mobile is foreground.
# Leaving CODM stops the virtual controller and releases MCON back to Android.
while [ ! -f "$MODDIR/disable" ]; do
    foreground_package="$(current_foreground_package)"
    if is_codm_foreground "$foreground_package"; then
        if ! bridge_running; then
            device="$(find_mcon)"
            if [ -n "$device" ]; then
                log "Creating Xbox controller for CODM from $device"
                "$BIN" --device "$device" >> "$LOG" 2>&1 &
                echo "$!" > "$PIDFILE"
            fi
        fi
    elif bridge_running; then
        log "Releasing Xbox controller; foreground package: ${foreground_package:-unknown}"
        stop_bridge
    fi
    sleep 2
done

stop_bridge
rm -f "$SERVICE_PIDFILE"
