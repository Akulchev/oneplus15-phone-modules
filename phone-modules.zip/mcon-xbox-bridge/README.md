# MCON Xbox Bridge v1.2-codm-only

This KernelSU module creates a virtual **Xbox Wireless Controller** from the
known OhSnap MCON only while **Call of Duty: Mobile** is foreground. Both the
global (`com.activision.callofduty.shooter`) and Garena
(`com.garena.game.codm`) editions are supported.

Outside CODM, the bridge stops and releases the physical MCON. This lets the
official MCON app receive its Home and Capture buttons normally. The module
does not launch or stop apps, watch buttons, or alter other controllers.

MCON is identified by its actual Bluetooth vendor/product ID (`045e:0b13`),
even when Android labels the device generically as `Bluetooth HID`.

The included Android key layout is scoped to the bridge's virtual Xbox
controller (`Vendor_045e_Product_02fd`) only, so its Xbox buttons are exposed
correctly without changing mappings for any other device.

Use KernelSU's **Action** button after updating to restart the bridge, or reboot.
The bridge log is at `/data/adb/mcon_xbox_bridge/mcon_xbox_bridge.log`.
