# MCON Fast Connect v0.4

Experimental KernelSU/Magisk module for the OnePlus 15 and OhSnap MCON.

The module temporarily raises Android's BLE scan duty cycle when a configured gaming app is foreground and the physical MCON is disconnected. It uses a short 20-second fast burst, then a lower-power warm scan. If Android's passive auto-connect has not succeeded after four seconds, a small root-side helper requests a direct HID Host connection. Retries are capped at six per foreground session.

The phone's stock scan values are restored as soon as MCON connects, Bluetooth is turned off, the target app closes, the module is disabled, or the module is uninstalled. The helper does not toggle the Bluetooth adapter, so other connected Bluetooth devices are not intentionally interrupted.

This can reduce phone-side discovery delay and recover from a stalled Android HID auto-connect. It cannot wake a closed controller or change how quickly MCON begins advertising. Open MCON and press A/B/X/Y once to wake it.

Runtime configuration is written to `/data/adb/mcon_fast_connect/config.conf`. Add package names to the comma-separated `TARGET_PACKAGES` value as needed.

The KernelSU action button toggles the daemon. Uninstalling restores the scan values captured before first use. The helper runs from the module with `app_process`; it does not require a `/system` mount or the Mountify metamodule.

## What v0.3 fixes

The previous daemon check trusted a saved PID alone. Android can reuse a PID after
the daemon has exited, which made the module incorrectly believe an unrelated
process was its running daemon. v0.3 validates the actual process command line
and launches the daemon in its own session, so it survives KernelSU's launcher
shell and can restart normally.

This module never calls Android's `removeBond` API. If the MCON disappears from
the Bluetooth paired-device list, another app or the Bluetooth stack removed the
pairing; pair it again once, then capture a Bluetooth bug report/log around the
next removal to identify that caller. Fast Connect can reconnect an existing
bond but cannot recreate a deleted pairing key.

## v0.4 behavior

The bundled target list now includes the local Winlator MCON shortcuts for
Bioshock 2, Spider-Man 3, Left 4 Dead 2, and GTA V. During a target app, the
direct HID request begins after one second, repeats every three seconds, and
the fast scan period lasts 45 seconds. Existing configuration is preserved;
the new shortcut package names are appended once.

The helper never issues a Bluetooth HID disconnect. A refused connection request
is reported in the module log rather than being forcibly reset.

## Input device policy repair

On this phone, Bluetooth diagnostics showed the MCON app changing MCON's HID
Host connection policy from `100` (enabled) to `0` (disabled). That is the
system Bluetooth **Input device** switch. Before every safe reconnect request,
the helper restores MCON's HID Host policy to `100`; it does not change the
policy of any other Bluetooth device and does not remove the MCON pairing.

v0.8 additionally checks the MCON-only policy every two seconds whenever the
controller is disconnected. This protects the Android Bluetooth setting even
when Settings, rather than the MCON app or a game, is foreground.
