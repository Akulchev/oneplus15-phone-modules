#!/system/bin/sh

MODDIR="${0%/*}"
STATE_DIR="/data/adb/mcon_fast_connect"
CONFIG="$STATE_DIR/config.conf"
PIDFILE="$STATE_DIR/daemon.pid"

daemon_is_ours() {
    pid="$1"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null || return 1
    [ -r "/proc/$pid/cmdline" ] || return 1
    tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null \
        | grep -F "$MODDIR/service.sh" 2>/dev/null \
        | grep -F -- '--mcon-fast-connect-daemon' >/dev/null 2>&1
}

mkdir -p "$STATE_DIR"

enabled="$(grep -m 1 '^ENABLED=' "$CONFIG" 2>/dev/null | cut -d= -f2-)"
if [ "$enabled" = "0" ]; then
    sed -i 's/^ENABLED=.*/ENABLED=1/' "$CONFIG"
    sh "$MODDIR/service.sh"
    echo "MCON Fast Connect enabled."
else
    if [ -f "$CONFIG" ]; then
        sed -i 's/^ENABLED=.*/ENABLED=0/' "$CONFIG"
    else
        echo 'ENABLED=0' > "$CONFIG"
    fi
    if [ -f "$PIDFILE" ]; then
        pid="$(cat "$PIDFILE" 2>/dev/null)"
        daemon_is_ours "$pid" && kill "$pid" 2>/dev/null
    fi
    echo "MCON Fast Connect disabled; stock scan settings will be restored."
fi
