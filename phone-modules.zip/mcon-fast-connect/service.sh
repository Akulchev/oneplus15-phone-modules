#!/system/bin/sh

MODDIR="${0%/*}"
STATE_DIR="/data/adb/mcon_fast_connect"
CONFIG="$STATE_DIR/config.conf"
ORIGINALS="$STATE_DIR/original_scan_settings.conf"
LOG="$STATE_DIR/mcon_fast_connect.log"
PIDFILE="$STATE_DIR/daemon.pid"
PROFILE_FILE="$STATE_DIR/current_profile"
HELPER_DEX="$MODDIR/bin/mcon-reconnect.dex"
HELPER_CLASS="com.codex.mconfastconnect.MconReconnectMain"
HELPER_PIDFILE="$STATE_DIR/helper.pid"
DAEMON_ARGUMENT="--mcon-fast-connect-daemon"

mkdir -p "$STATE_DIR"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

read_config() {
    key="$1"
    fallback="$2"
    if [ -f "$CONFIG" ]; then
        value="$(grep -m 1 "^$key=" "$CONFIG" 2>/dev/null | cut -d= -f2-)"
        if [ -n "$value" ]; then
            echo "$value"
            return
        fi
    fi
    echo "$fallback"
}

read_original() {
    key="$1"
    fallback="$2"
    if [ -f "$ORIGINALS" ]; then
        value="$(grep -m 1 "^$key=" "$ORIGINALS" 2>/dev/null | cut -d= -f2-)"
        case "$value" in
            ''|*[!0-9]*) ;;
            *) echo "$value"; return ;;
        esac
    fi
    echo "$fallback"
}

global_number() {
    key="$1"
    fallback="$2"
    value="$(settings get global "$key" 2>/dev/null)"
    case "$value" in
        ''|null|*[!0-9]*) echo "$fallback" ;;
        *) echo "$value" ;;
    esac
}

write_default_config() {
    [ -f "$CONFIG" ] && return
    cat > "$CONFIG" <<'EOF'
ENABLED=1
POLL_SECONDS=1
FAST_BURST_SECONDS=45
FAST_SCAN_INTERVAL_MS=300
FAST_SCAN_WINDOW_MS=300
WARM_SCAN_INTERVAL_MS=730
WARM_SCAN_WINDOW_MS=183
ACTIVE_CONNECT_DELAY_SECONDS=1
ACTIVE_CONNECT_RETRY_SECONDS=3
ACTIVE_CONNECT_MAX_ATTEMPTS=12
POLICY_GUARD_SECONDS=15
TARGET_PACKAGES=dev.eden.eden_emulator,com.activision.callofduty.shooter,com.ohsnap.mconutilities,com.radikal.gamelauncher,com.codex.oneplus.gamefpsonly,com.epicgames.fortnite,com.gameloft.anmp.disney.speedstorm,com.kitkagames.fallbuddies,com.akulchev.winlatormcon.bioshock2,com.akulchev.winlatormcon.spiderman3,com.akulchev.winlatormcon.left4dead2,com.akulchev.winlatormcon.gta5
EOF
    chmod 600 "$CONFIG" 2>/dev/null
}

ensure_config_key() {
    key="$1"
    value="$2"
    grep -q "^$key=" "$CONFIG" 2>/dev/null || echo "$key=$value" >> "$CONFIG"
}

update_config_if_value() {
    key="$1"
    old_value="$2"
    new_value="$3"
    current_value="$(read_config "$key" '')"
    [ "$current_value" = "$old_value" ] || return
    sed -i "s|^$key=.*|$key=$new_value|" "$CONFIG"
}

migrate_config() {
    # Upgrade only values that are still the old defaults; never overwrite a
    # user-tuned reconnect policy.
    update_config_if_value FAST_BURST_SECONDS 20 45
    update_config_if_value ACTIVE_CONNECT_DELAY_SECONDS 4 1
    update_config_if_value ACTIVE_CONNECT_RETRY_SECONDS 10 3
    update_config_if_value ACTIVE_CONNECT_MAX_ATTEMPTS 6 12
    ensure_config_key ACTIVE_CONNECT_DELAY_SECONDS 1
    ensure_config_key ACTIVE_CONNECT_RETRY_SECONDS 3
    ensure_config_key ACTIVE_CONNECT_MAX_ATTEMPTS 12
    ensure_config_key POLICY_GUARD_SECONDS 15
    ensure_target_package com.akulchev.winlatormcon.bioshock2
    ensure_target_package com.akulchev.winlatormcon.spiderman3
    ensure_target_package com.akulchev.winlatormcon.left4dead2
    ensure_target_package com.akulchev.winlatormcon.gta5
}

ensure_target_package() {
    package="$1"
    targets="$(read_config TARGET_PACKAGES '')"
    case ",$targets," in
        *",$package,"*) return ;;
    esac
    if grep -q '^TARGET_PACKAGES=' "$CONFIG" 2>/dev/null; then
        sed -i "s|^TARGET_PACKAGES=.*|TARGET_PACKAGES=$targets,$package|" "$CONFIG"
    else
        echo "TARGET_PACKAGES=$package" >> "$CONFIG"
    fi
}

save_originals_once() {
    [ -f "$ORIGINALS" ] && return
    low_interval="$(global_number ble_scan_low_power_interval_ms 1400)"
    low_window="$(global_number ble_scan_low_power_window_ms 140)"
    balanced_interval="$(global_number ble_scan_balanced_interval_ms 730)"
    balanced_window="$(global_number ble_scan_balanced_window_ms 183)"

    cat > "$ORIGINALS" <<EOF
BLE_SCAN_LOW_POWER_INTERVAL_MS=$low_interval
BLE_SCAN_LOW_POWER_WINDOW_MS=$low_window
BLE_SCAN_BALANCED_INTERVAL_MS=$balanced_interval
BLE_SCAN_BALANCED_WINDOW_MS=$balanced_window
EOF
    chmod 600 "$ORIGINALS" 2>/dev/null
}

set_scan_values() {
    low_interval="$1"
    low_window="$2"
    balanced_interval="$3"
    balanced_window="$4"

    settings put global ble_scan_low_power_interval_ms "$low_interval"
    settings put global ble_scan_low_power_window_ms "$low_window"
    settings put global ble_scan_balanced_interval_ms "$balanced_interval"
    settings put global ble_scan_balanced_window_ms "$balanced_window"
}

apply_profile() {
    profile="$1"
    current="$(cat "$PROFILE_FILE" 2>/dev/null)"
    [ "$current" = "$profile" ] && return

    case "$profile" in
        fast)
            interval="$(read_config FAST_SCAN_INTERVAL_MS 300)"
            window="$(read_config FAST_SCAN_WINDOW_MS 300)"
            set_scan_values "$interval" "$window" "$interval" "$window"
            log "Fast reconnect scan enabled"
            ;;
        warm)
            interval="$(read_config WARM_SCAN_INTERVAL_MS 730)"
            window="$(read_config WARM_SCAN_WINDOW_MS 183)"
            set_scan_values "$interval" "$window" "$interval" "$window"
            log "Warm reconnect scan enabled"
            ;;
        stock)
            set_scan_values \
                "$(read_original BLE_SCAN_LOW_POWER_INTERVAL_MS 1400)" \
                "$(read_original BLE_SCAN_LOW_POWER_WINDOW_MS 140)" \
                "$(read_original BLE_SCAN_BALANCED_INTERVAL_MS 730)" \
                "$(read_original BLE_SCAN_BALANCED_WINDOW_MS 183)"
            log "Stock BLE scan settings restored"
            ;;
        *) return ;;
    esac

    echo "$profile" > "$PROFILE_FILE"
}

controller_connected() {
    for name_file in /sys/class/input/event*/device/name; do
        [ -f "$name_file" ] || continue
        name="$(cat "$name_file" 2>/dev/null | tr 'A-Z' 'a-z')"
        case "$name" in
            *"ohsnap mcon"*) return 0 ;;
        esac
    done
    return 1
}

current_foreground_package() {
    dumpsys window 2>/dev/null \
        | sed -n 's|.*mCurrentFocus=.* u[0-9][0-9]* \([^/ ]*\)/.*|\1|p'
}

target_is_foreground() {
    package="$1"
    [ -n "$package" ] || return 1
    targets="$(read_config TARGET_PACKAGES '')"
    case ",$targets," in
        *",$package,"*) return 0 ;;
    esac
    return 1
}

start_helper() {
    helper_mode="$1"
    helper_message="$2"
    if [ -f "$HELPER_PIDFILE" ] && helper_pid_alive "$(cat "$HELPER_PIDFILE" 2>/dev/null)"; then
        return 1
    fi
    rm -f "$HELPER_PIDFILE" 2>/dev/null

    if [ ! -f "$HELPER_DEX" ]; then
        log "Root reconnect helper is unavailable"
        return 1
    fi

    (
        CLASSPATH="$HELPER_DEX" app_process /system/bin "$HELPER_CLASS" "$helper_mode"
        rm "$HELPER_PIDFILE" 2>/dev/null
    ) >> "$LOG" 2>&1 &
    echo "$!" > "$HELPER_PIDFILE"
    log "$helper_message"
    return 0
}

request_active_reconnect() {
    start_helper "" "Root HID reconnect helper started"
}

request_input_policy_enable() {
    start_helper "--policy-only" "MCON Input device policy guard started"
}

# When the dedicated, address-pinned policy module is installed it owns the
# always-on policy repair. Keeping a second helper in this module would make
# two app_process instances contend for the same HID Host profile precisely
# while a controller is trying to reconnect.
dedicated_policy_guard_active() {
    [ -d "/data/adb/modules/mcon_input_device_guard" ] \
        && [ ! -f "/data/adb/modules/mcon_input_device_guard/disable" ]
}

module_enabled() {
    [ ! -f "$MODDIR/disable" ] && [ "$(read_config ENABLED 1)" = "1" ]
}

pid_alive() {
    pid="$1"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

# A PID by itself is not an identity. Android can reuse it after the daemon
# exits; the old implementation then treated an unrelated process as this
# module and never started again until a reboot happened to free that PID.
daemon_pid_alive() {
    pid="$1"
    pid_alive "$pid" || return 1
    [ -r "/proc/$pid/cmdline" ] || return 1
    tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null \
        | grep -F "$MODDIR/service.sh" 2>/dev/null \
        | grep -F -- "$DAEMON_ARGUMENT" >/dev/null 2>&1
}

# app_process does not keep the dex path in its command line, but it does keep
# CLASSPATH in its environment. This avoids the same stale-PID failure for a
# completed reconnect helper.
helper_pid_alive() {
    pid="$1"
    pid_alive "$pid" || return 1
    [ -r "/proc/$pid/environ" ] || return 1
    tr '\000' '\n' < "/proc/$pid/environ" 2>/dev/null \
        | grep -Fx "CLASSPATH=$HELPER_DEX" >/dev/null 2>&1
}

cleanup() {
    apply_profile stock
    if [ -f "$HELPER_PIDFILE" ]; then
        helper_pid="$(cat "$HELPER_PIDFILE" 2>/dev/null)"
        helper_pid_alive "$helper_pid" && kill "$helper_pid" 2>/dev/null
        rm "$HELPER_PIDFILE" 2>/dev/null
    fi
    rm "$PIDFILE" 2>/dev/null
}

terminate() {
    log "MCON Fast Connect stopping"
    exit 0
}

daemon_loop() {
    until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
        sleep 2
    done
    sleep 4

    write_default_config
    migrate_config
    save_originals_once
    trap cleanup EXIT
    trap terminate TERM INT
    log "MCON Fast Connect daemon started"

    disconnected_since=0
    last_active_request=0
    active_request_count=0
    last_policy_guard=0
    while module_enabled; do
        if [ "$(settings get global bluetooth_on 2>/dev/null)" != "1" ]; then
            disconnected_since=0
            last_active_request=0
            active_request_count=0
            last_policy_guard=0
            apply_profile stock
        elif controller_connected; then
            disconnected_since=0
            last_active_request=0
            active_request_count=0
            last_policy_guard=0
            apply_profile stock
        else
            now="$(date +%s)"
            if ! dedicated_policy_guard_active; then
                guard_seconds="$(read_config POLICY_GUARD_SECONDS 15)"
                if [ "$last_policy_guard" -eq 0 ] \
                    || [ $((now - last_policy_guard)) -ge "$guard_seconds" ]; then
                    if request_input_policy_enable; then
                        last_policy_guard="$now"
                    fi
                fi
            fi
            foreground_package="$(current_foreground_package)"
            if target_is_foreground "$foreground_package"; then
                if [ "$disconnected_since" -eq 0 ]; then
                    disconnected_since="$now"
                    log "Reconnect acceleration started for a configured foreground app"
                fi

                elapsed=$((now - disconnected_since))
                if [ "$elapsed" -lt "$(read_config FAST_BURST_SECONDS 20)" ]; then
                    apply_profile fast
                else
                    apply_profile warm
                fi

                active_delay="$(read_config ACTIVE_CONNECT_DELAY_SECONDS 4)"
                retry_seconds="$(read_config ACTIVE_CONNECT_RETRY_SECONDS 10)"
                max_attempts="$(read_config ACTIVE_CONNECT_MAX_ATTEMPTS 6)"
                since_last_request=$((now - last_active_request))
                if [ "$elapsed" -ge "$active_delay" ] \
                    && [ "$active_request_count" -lt "$max_attempts" ] \
                    && { [ "$last_active_request" -eq 0 ] || [ "$since_last_request" -ge "$retry_seconds" ]; }; then
                    if request_active_reconnect; then
                        last_active_request="$now"
                        active_request_count=$((active_request_count + 1))
                    fi
                fi
            else
                disconnected_since=0
                last_active_request=0
                active_request_count=0
                apply_profile stock
            fi
        fi

        sleep "$(read_config POLL_SECONDS 1)"
    done

    log "MCON Fast Connect disabled"
}

if [ "$1" = "$DAEMON_ARGUMENT" ]; then
    daemon_loop
    exit 0
fi

if [ -f "$PIDFILE" ] && daemon_pid_alive "$(cat "$PIDFILE" 2>/dev/null)"; then
    exit 0
fi

# KernelSU runs service.sh in a managed shell. Start a separate session so the
# daemon survives after that shell returns, including starts from action.sh.
rm -f "$PIDFILE" 2>/dev/null
setsid sh "$MODDIR/service.sh" "$DAEMON_ARGUMENT" </dev/null >/dev/null 2>&1 &
echo "$!" > "$PIDFILE"
