#!/system/bin/sh

STATE_DIR="/data/adb/mcon_fast_connect"
ORIGINALS="$STATE_DIR/original_scan_settings.conf"
PIDFILE="$STATE_DIR/daemon.pid"

read_original() {
    key="$1"
    fallback="$2"
    value="$(grep -m 1 "^$key=" "$ORIGINALS" 2>/dev/null | cut -d= -f2-)"
    case "$value" in
        ''|*[!0-9]*) echo "$fallback" ;;
        *) echo "$value" ;;
    esac
}

if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
fi

settings put global ble_scan_low_power_interval_ms "$(read_original BLE_SCAN_LOW_POWER_INTERVAL_MS 1400)"
settings put global ble_scan_low_power_window_ms "$(read_original BLE_SCAN_LOW_POWER_WINDOW_MS 140)"
settings put global ble_scan_balanced_interval_ms "$(read_original BLE_SCAN_BALANCED_INTERVAL_MS 730)"
settings put global ble_scan_balanced_window_ms "$(read_original BLE_SCAN_BALANCED_WINDOW_MS 183)"

rm -rf "$STATE_DIR"
